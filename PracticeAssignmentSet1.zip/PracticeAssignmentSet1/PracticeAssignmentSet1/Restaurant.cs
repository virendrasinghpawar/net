﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PracticeAssignmentSet1
{
    //Don't change anything in enum SearchBy
    public enum SearchBy { Id, Name, City, Area };

    //Don't change anything in enum SortBy
    public enum SortBy { Id, Name, City, Area };

    //Don't change name or access specifier of class 'Restaurant'
    //Don't modify existing member of class, but you can add more members as per your requirements
    public class Restaurant
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string Area { get; set; }
    }
}
