﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace PracticeAssignmentSet1
{
    /* --> VERY IMPORTANT INSTRUCTIONS <--
     * If you fail in any one of these important instructions, your code will not be graded
     * 
     * Don't change name or access specifier of class 'Program' 
     * Don't use Console.ReadLine or Console.ReadKey or Console.Read in methods to be implemented, you are free to use it inside Main method only.
     * Don't use Environment.Exit in methods to be implemented.     
     */

    public class Program
    {        
        static void Main(string[] args)
        {
            //You can call methods to test here.
            
            Console.ReadKey();
        }

        public static List<Restaurant> GetRestaurantsFromFile(FileStream fs)
        {
            List<Restaurant> allRestaurants = new List<Restaurant>();
            StreamReader sr = new StreamReader(fs);
            while (!sr.EndOfStream)
            {
                string[] restDetails = sr.ReadLine().Split(',');
                Restaurant restaurant = new Restaurant() { Id = int.Parse(restDetails[0]), Name = restDetails[1], City = restDetails[2], Area = restDetails[3] };
                allRestaurants.Add(restaurant);
            }
            sr.Close();
            fs.Close();
            if (allRestaurants.Count == 0)
                allRestaurants = null;
            return allRestaurants;
        }

        public static List<Restaurant> SearchRestaurantsBy(SearchBy searchBy, string searchFilter, List<Restaurant> allRestaurants)
        {
            List<Restaurant> searchResult = new List<Restaurant>();

            if (searchBy == SearchBy.Name)
            {
                foreach (var r1 in allRestaurants)
                    if (r1.Name == searchFilter)
                        searchResult.Add(r1);
            }
            else if (searchBy == SearchBy.City)
            {
                foreach (var r2 in allRestaurants)
                    if (r2.City == searchFilter)
                        searchResult.Add(r2);
            }
            else if (searchBy == SearchBy.Area)
            {
                foreach (var r3 in allRestaurants)
                    if (r3.Area == searchFilter)
                        searchResult.Add(r3);
            }
            else if (searchBy == SearchBy.Id)
            {
                foreach (var r4 in allRestaurants)
                    if (r4.Id.ToString() == searchFilter)
                        searchResult.Add(r4);
            }
            return searchResult;
        }

        public static List<Restaurant> SortRestaurantsBy(SortBy sortBy, List<Restaurant> allRestaurants)
        {
            List<Restaurant> restaurants = null;
            if (sortBy == SortBy.Name)
            {
                restaurants = allRestaurants.OrderBy(r => r.Name).ToList();
            }
            else if (sortBy == SortBy.Area)
            {
                restaurants = allRestaurants.OrderBy(r => r.Area).ToList();
            }
            else if (sortBy == SortBy.City)
            {
                restaurants = allRestaurants.OrderBy(r => r.City).ToList();
            }
            else if (sortBy == SortBy.Id)
            {
                restaurants = allRestaurants.OrderBy(r => r.Id).ToList();
            }
            return restaurants;
        }

        public static List<Restaurant> AutoCompleteSearchRestaurantByName(string restaurantSubString, List<Restaurant> restaurants)
        {
            List<Restaurant> autocomplete = new List<Restaurant>();

            string substring = restaurantSubString;

            for (int i = 0; i < restaurants.Count(); i++)
            {
                string sub = restaurants[i].Name.ToString();
                if (sub.Contains(substring))
                {
                    autocomplete.Add(restaurants[i]);
                }
            }

            return autocomplete;
        }               
    }
}