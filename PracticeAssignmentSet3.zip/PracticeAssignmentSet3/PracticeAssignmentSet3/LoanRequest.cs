﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeAssignmentSet3
{
    //Don't change anything in enum LoanType
    public enum LoanType { PersonalLoan = 1, HomeLoan, GoldLoan };

    //Don't change name or access specifier of class 'LoanRequest'
    //Don't modify existing member of class, but you can add more members as per your requirements
    public class LoanRequest
    {
        public int RequestId { get; set; }
        public string ApplicantId { get; set; }
        public DateTime RequestDate { get; set; }
        public LoanType TypeOfLoan { get; set; }
        public double LoanAmount { get; set; }
        public int TenureOfLoan { get; set; }
        public string BankName { get; set; }
        public string MarketingExecutiveName { get; set; }

        public override string ToString()
        {
            return string.Format("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}", RequestId, ApplicantId, RequestDate.ToString("yyyy-MM-dd"), TypeOfLoan, LoanAmount, TenureOfLoan, BankName, MarketingExecutiveName);
        }
    }
}
