using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace PracticeAssignmentSet3
{
    //Don't change name or access specifier of class 'Program'
    public class Program
    {
        public static void Main(string[] args)
        {
            //You can call methods to test here.            

            List<MarketingExecutive> marketingExecutives = new List<MarketingExecutive>();
            List<FieldOfficer> fieldOfficers = new List<FieldOfficer>();
            List<LoanRequest> loanRequests = new List<LoanRequest> ();
            MySqlConnection cn = new MySqlConnection("datasource=localhost;port=3306;username=root;password=root;");

            //1. InitializeUsers            
            InitializeUsers(cn, marketingExecutives, fieldOfficers);

            //2. InitializeLoanRequests
            InitializeLoanRequests(cn,loanRequests);

            //3. GetTypeOfUserByUserName
            Type empType = GetTypeOfUserByUserName("Harshali Jain", marketingExecutives, fieldOfficers);
                        
            //4. DivideLoanRequestsByExecutive            
            string csvFileDirPath = "C:/Que1/CsvFileDir";
            DivideLoanRequestsByExecutive(loanRequests, "Girija Mathur", csvFileDirPath);

            //5. SplitLoanRequestsIntoXML            
            string xmlFileDirPath = "C:/Que1/XmlFileDir";
            SplitLoanRequestsIntoXML(xmlFileDirPath, loanRequests);

            Console.ReadKey();
        }

        #region Helper Methods

        private static void LoadFieldOfficers(MySqlConnection cn, List<FieldOfficer> fieldOfficers)
        {
            MySqlCommand cmd = new MySqlCommand("select * from LoanRequestProcessing_db.Tbl_Users where TypeOfuser = 'Field Officer'", cn);
            cn.Open();            
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                FieldOfficer fieldOfficer = new FieldOfficer ();
                fieldOfficer.OfficerId = Convert.ToInt32(reader[0]);
                fieldOfficer.OfficerName = reader[1].ToString();                
                fieldOfficer.Area = reader[3].ToString();
                fieldOfficer.Address = reader[4].ToString();
                fieldOfficers.Add(fieldOfficer);
            }
            reader.Close();
            cn.Close();            
        }

        private static void LoadMarketingExecutives(MySqlConnection cn, List<MarketingExecutive> marketingExecutives)
        {
            MySqlCommand cmd = new MySqlCommand("select * from LoanRequestProcessing_db.Tbl_Users where TypeOfuser = 'Marketing Executive'", cn);
            cn.Open();            
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                MarketingExecutive marketingExecutive = new MarketingExecutive();
                marketingExecutive.ExecutiveId= Convert.ToInt32(reader[0]);
                marketingExecutive.ExecutiveName = reader[1].ToString();
                marketingExecutive.Area = reader[3].ToString();
                marketingExecutive.Address = reader[4].ToString();
                marketingExecutives.Add(marketingExecutive);
            }
            reader.Close();
            cn.Close();         
        }
       
        #endregion 
                    
        public static void InitializeUsers(MySqlConnection cn, List<MarketingExecutive> marketingExecutives, List<FieldOfficer> fieldOfficers)
        {       
            LoadFieldOfficers(cn, fieldOfficers);
            LoadMarketingExecutives(cn, marketingExecutives);
        }

        public static void InitializeLoanRequests(MySqlConnection cn, List<LoanRequest> loanRequests)
        {
            MySqlCommand cmd = new MySqlCommand("select * from LoanRequestProcessing_db.Tbl_LoanRequests", cn);
            cn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                LoanRequest loanRequest = new LoanRequest();
                loanRequest.RequestId = Convert.ToInt32( reader[0]);
                loanRequest.ApplicantId = reader[1].ToString();
                loanRequest.RequestDate = DateTime.Parse(reader[2].ToString());
                loanRequest.TypeOfLoan = (LoanType)Enum.Parse(typeof(LoanType), reader[3].ToString());
                loanRequest.LoanAmount = Convert.ToDouble(reader[4]);
                loanRequest.TenureOfLoan = Convert.ToInt32(reader[5]);
                loanRequest.BankName = reader[6].ToString();
                loanRequest.MarketingExecutiveName = reader[7].ToString();
                loanRequests.Add(loanRequest);
            }
            reader.Close();
            cn.Close();
        }

        public static Type GetTypeOfUserByUserName(string userName, List<MarketingExecutive> marketingExecutives, List<FieldOfficer> fieldOfficers)
        {      
            Type empType = null;
            FieldOfficer fo = fieldOfficers.Where(f => f.OfficerName == userName).FirstOrDefault();
            if (fo != null)
            {
                empType = fo.GetType();
            }
            else
            {
                MarketingExecutive me = marketingExecutives.Where(m => m.ExecutiveName == userName).FirstOrDefault();
                if (me != null)
                    empType = me.GetType();
                else
                    throw new UserNotRegisteredException("User is Not Registered !");
            }
            return empType;     
        }

        public static void DivideLoanRequestsByExecutive(List<LoanRequest> loanRequests, string executiveName, string csvFileDirPath)
        {            
            int requestId;
            string fileName = csvFileDirPath + "/" + "LoanRequests_" + executiveName + ".csv";
            var filteredRequests = loanRequests.Where(lr => lr.MarketingExecutiveName == executiveName).ToList();

            FileStream fs = null;
            if (File.Exists(fileName))
            {
                requestId = File.ReadAllLines(fileName).Length + 1;
                fs = new FileStream(fileName, FileMode.Append);
            }
            else
            {
                requestId = 1;
                fs = new FileStream(fileName, FileMode.Create);
            }

            StreamWriter sw = new StreamWriter(fs);
            string continueAgain = string.Empty;
            List<LoanRequest> loanRequestList = new List<LoanRequest>();

            foreach (LoanRequest lr in filteredRequests)
            {
                lr.RequestId = requestId;
                sw.WriteLine(lr.RequestId + "," + lr.ApplicantId + "," + lr.RequestDate + "," + lr.TypeOfLoan + "," + lr.LoanAmount + "," + lr.TenureOfLoan + "," + lr.BankName+","+ lr.MarketingExecutiveName);
                requestId++;
            }
            sw.Close();
            fs.Close();
        }

        public static void SplitLoanRequestsIntoXML(string xmlFileDirPath, List<LoanRequest> loanRequests)
        {
            string xmlFileName = string.Empty;
            List<string> distinctBankNames = loanRequests.Select(lr => lr.BankName).Distinct().ToList();
            foreach (string bankName in distinctBankNames)
            {                
                xmlFileName = xmlFileDirPath +"/"+ DateTime.Now.ToString("yyyy-MM-dd") + "_" + bankName.Remove(bankName.IndexOf(' '), 1) + ".xml";
                XmlDocument xDoc = new XmlDocument();
                XmlElement root = xDoc.CreateElement("LoanRequests");
                List<LoanRequest> bankLoanRequets = loanRequests.Where(r => r.BankName == bankName).ToList();
                foreach (LoanRequest lr in bankLoanRequets)
                {
                    XmlElement lrElement = xDoc.CreateElement("Request");

                    XmlElement rIdElement = xDoc.CreateElement("RequestId");
                    rIdElement.InnerText = lr.RequestId.ToString();
                    lrElement.AppendChild(rIdElement);

                    XmlElement appIdElement = xDoc.CreateElement("ApplicantId");
                    appIdElement.InnerText = lr.ApplicantId;
                    lrElement.AppendChild(appIdElement);

                    XmlElement reqDateElement = xDoc.CreateElement("RequestDate");
                    reqDateElement.InnerText = lr.RequestDate.ToString("yyyy-MM-dd");
                    lrElement.AppendChild(reqDateElement);

                    XmlElement lTypeElement = xDoc.CreateElement("TypeOfLoan");
                    lTypeElement.InnerText = lr.TypeOfLoan.ToString();
                    lrElement.AppendChild(lTypeElement);

                    XmlElement lAmtElement = xDoc.CreateElement("LoanAmount");
                    lAmtElement.InnerText = lr.LoanAmount.ToString();
                    lrElement.AppendChild(lAmtElement);

                    XmlElement lTenureElement = xDoc.CreateElement("TenureOfLoan");
                    lTenureElement.InnerText = lr.TenureOfLoan.ToString();
                    lrElement.AppendChild(lTenureElement);

                    XmlElement lmarExName = xDoc.CreateElement("MarketingExecutiveName");
                    lmarExName.InnerText = lr.MarketingExecutiveName;
                    lrElement.AppendChild(lmarExName);

                    root.AppendChild(lrElement);
                }
                xDoc.AppendChild(root);
                xDoc.Save(xmlFileName);
            }
        }
    }
}
