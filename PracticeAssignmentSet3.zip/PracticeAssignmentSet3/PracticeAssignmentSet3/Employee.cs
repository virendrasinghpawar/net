﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeAssignmentSet3
{
    //Don't change name or access specifier of class 'Employee'
    //Don't modify existing member of class, but you can add more members as per your requirements
    public abstract class Employee
    {
        protected int EmpId { get; set; }
        protected string EmpName { get; set; }
        public string Area { get; set; }
        public string Address { get; set; }

        public override string ToString()
        {
            return string.Format("Id: {0}, Name: {1}, Area: {2}, Address: {3}", EmpId, EmpName, Area, Address);
        }
    }

    //Don't change name or access specifier of class 'MarketingExecutive'
    //Don't modify existing member of class, but you can add more members as per your requirements
    public class MarketingExecutive : Employee
    {
        public int ExecutiveId { get { return EmpId; } set { EmpId = value; } }
        public string ExecutiveName { get { return EmpName; } set { EmpName = value; } }
    }

    //Don't change name or access specifier of class 'FieldOfficer'
    //Don't modify existing member of class, but you can add more members as per your requirements
    public class FieldOfficer : Employee
    {
        public int OfficerId { get { return EmpId; } set { EmpId = value; } }
        public string OfficerName { get { return EmpName; } set { EmpName = value; } }
    }
}
