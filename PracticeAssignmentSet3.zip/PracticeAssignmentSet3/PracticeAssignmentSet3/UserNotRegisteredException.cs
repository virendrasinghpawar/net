﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeAssignmentSet3
{
    //Don't change name or access specifier of class 'UserNotRegisteredException'
    //Don't modify existing member of class, but you can add more members as per your requirements
    public class UserNotRegisteredException: ApplicationException
    {
        public UserNotRegisteredException(string message) : base(message) { }
    }
}
