﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace PracticeAssignmentSet2
{
    /* --> VERY IMPORTANT INSTRUCTIONS <--
    * If you fail in any one of these important instructions, your code will not be graded
    * 
    * Don't change name or access specifier of class 'Program' 
    * Don't use Console.ReadLine or Console.ReadKey or Console.Read in methods to be implemented, you are free to use it inside Main method only.
    * Don't use Environment.Exit in methods to be implemented.     
    */

    public class Program
    {        
        static void Main(string[] args)
        {
            //You can call methods to test here.

            //1. GetRestaurantsAsDictionaryFromFile
            FileStream fs = new FileStream("Restaurants.csv", FileMode.Open);
            Dictionary<FoodType, List<Restaurant>> restaurants = GetRestaurantsAsDictionaryFromFile(fs);

            //2. AddNewRestaurant
            Restaurant rest = new Restaurant() { Name = "Pizzeria House", City = "Vashi", Address = "Raghuleela Mall, Sector 30", Area = "Railway Station", Cuisine = FoodType.Mexican };
            AddNewRestaurant(rest, restaurants);

            //3. SearchRestaurantsByCuisineAndSerialize
            FoodType ft1 = FoodType.Mexican;
            FileStream fsSerialize = new FileStream(Enum.GetName(typeof(FoodType), ft1)+".txt", FileMode.Create);
            List<Restaurant> searchedResult = SearchRestaurantsByCuisineAndSerialize(ft1, restaurants, fsSerialize);

            //4. LoadSerializedSearchResult
            FoodType ft2 = FoodType.Mexican;
            FileStream fsDeserialize = new FileStream(Enum.GetName(typeof(FoodType), ft2) + ".txt", FileMode.Open);
            List<Restaurant> serializedSearchResult = LoadSerializedSearchResult(fsDeserialize);

            Console.ReadKey();
        }

        public static Dictionary<FoodType, List<Restaurant>> GetRestaurantsAsDictionaryFromFile(FileStream fs)
        {
            Dictionary<FoodType, List<Restaurant>> restaurantsDic = new Dictionary<FoodType, List<Restaurant>>();
            List<Restaurant> restaurants = new List<Restaurant>();                      
            StreamReader sr = new StreamReader(fs);
            while (!sr.EndOfStream)
            {
                string[] restDetails = sr.ReadLine().Split(',');
                Restaurant restaurant = new Restaurant() { Id = int.Parse(restDetails[0]), Name = restDetails[1], City = restDetails[2], Area = restDetails[3], Address = restDetails[4], Cuisine = (FoodType)Enum.Parse(typeof(FoodType), restDetails[5]) };
                restaurants.Add(restaurant);
            }
            sr.Close();
            fs.Close();
                    
            foreach (Restaurant rest in restaurants)
            {
                if (!restaurantsDic.ContainsKey(rest.Cuisine))
                {
                    restaurantsDic.Add(rest.Cuisine, new List<Restaurant>() { rest });
                }
                else
                {
                    restaurantsDic[rest.Cuisine].Add(rest);
                }
            }
            return restaurantsDic;
        }

        public static void AddNewRestaurant(Restaurant restaurant, Dictionary<FoodType, List<Restaurant>> restaurants)
        {
            int count = (from keyVal in restaurants
                         select keyVal.Value.Count).Sum();

            restaurant.Id = count + 1;

            if (restaurants.ContainsKey(restaurant.Cuisine))
            {
                restaurants[restaurant.Cuisine].Add(restaurant);
            }
            else
            {
                restaurants.Add(restaurant.Cuisine, new List<Restaurant> { restaurant });
            }
        }

        public static List<Restaurant> SearchRestaurantsByCuisineAndSerialize(FoodType cuisine, Dictionary<FoodType, List<Restaurant>> allRestaurants, FileStream fs)
        {
            List<Restaurant> restaurants = null;

            if (allRestaurants.ContainsKey(cuisine))
            {
                restaurants = allRestaurants[cuisine];                
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, restaurants);
                fs.Close();
            }
            else
                throw new NoSuchRestauranFoundException();

            return restaurants;
        }

        public static List<Restaurant> LoadSerializedSearchResult(FileStream fs)
        {
            List<Restaurant> restaurants = null;            
            try
            {
                BinaryFormatter bf = new BinaryFormatter();
                restaurants = (List<Restaurant>)bf.Deserialize(fs);
                fs.Close();                
            }
            catch (SerializationException ex)
            {
                throw new InvalidSerializedFileFormatException(ex.Message);
            }
            return restaurants;
        }                       
    }
}