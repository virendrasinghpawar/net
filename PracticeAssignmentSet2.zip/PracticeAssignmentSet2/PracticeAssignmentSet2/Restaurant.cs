﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PracticeAssignmentSet2
{
    //Don't change anything in enum FoodType
    public enum FoodType { SouthIndian = 1, Punjabi, Italian, Mexican, Chinese, Other };        

    //Don't change name or access specifier of class 'Restaurant'
    //Don't modify existing member of class, but you can add more members as per your requirements    
    [Serializable]
    public class Restaurant
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string Area { get; set; }
        public string Address { get; set; }
        public FoodType Cuisine { get; set; }

        public override string ToString()
        {
            return string.Format(Id.ToString().PadRight(3) + Name.PadRight(17) + City.PadRight(10) + Area.PadRight(13) + Address.PadRight(25) + Cuisine.ToString().PadRight(22));
        }          
    }
}
