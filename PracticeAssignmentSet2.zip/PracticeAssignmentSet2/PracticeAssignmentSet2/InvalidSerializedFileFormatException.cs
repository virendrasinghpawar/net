﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeAssignmentSet2
{
    //Don't change implementation of class 'InvalidSerializedFileFormatException'
    public class InvalidSerializedFileFormatException : ApplicationException
    {       
        public InvalidSerializedFileFormatException(string message) : base(message) { }

        public InvalidSerializedFileFormatException()
            : base("Invalid Serialized File-Format Exception") { }         
    }    
}
