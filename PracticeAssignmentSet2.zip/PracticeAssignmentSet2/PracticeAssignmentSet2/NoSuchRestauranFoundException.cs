﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeAssignmentSet2
{
    //Don't change implementation of class 'NoSuchRestauranFoundException'
    public class NoSuchRestauranFoundException : ApplicationException
    {
        public NoSuchRestauranFoundException(string message) : base(message) { }

        public NoSuchRestauranFoundException() : base("No Such Restauran Found Exception") { }
    }
}
